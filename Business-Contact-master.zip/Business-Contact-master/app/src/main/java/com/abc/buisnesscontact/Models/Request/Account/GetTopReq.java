package com.abc.buisnesscontact.Models.Request.Account;

import com.abc.buisnesscontact.Models.Response.Account.AuthToken;

public class GetTopReq {
    public String  Token;

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }
}
