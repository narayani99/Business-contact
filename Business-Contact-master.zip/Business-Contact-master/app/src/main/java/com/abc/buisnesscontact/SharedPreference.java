package com.abc.buisnesscontact;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreference {

    private SharedPreferences sp;
    private Context ct;

    public SharedPreference(Context ct){

        this.ct = ct;
        sp = ct.getSharedPreferences(ct.getResources().getString(R.string.preference),Context.MODE_PRIVATE);

    }

    public void writeLoginStatus(Boolean b)
    {
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean(ct.getResources().getString(R.string.login_status_preference), b);
        editor.apply();
    }

    public boolean readLoginStatus()
    {
        boolean status = false;
        status = sp.getBoolean(ct.getResources().getString(R.string.login_status_preference),false);
        return status;
    }

    public void writeUsername(String username)
    {
        SharedPreferences.Editor editor = sp.edit ();
        editor.putString ( "com.abc.sharedpreferences_login_username",username );
        editor.apply ();
    }

    public String readUsername()
    {
        String username;
        username = sp.getString(ct.getResources().getString(R.string.login_username),"");
        return username;
    }

    public void writeOUserid(int role)
    {
        SharedPreferences.Editor editor = sp.edit ();
        editor.putString ( "com.abc.sharedpreferences_login_id",Integer.toString ( role ) );
        editor.apply ();

    }
    public int readOUserid()
    {
        int role;
        role = Integer.parseInt ( sp.getString(ct.getResources().getString(R.string.login_id),"0"));
        return role;
    }

    public void writeToken(String token)
    {
        SharedPreferences.Editor editor = sp.edit ();
        editor.putString ( "com.abc.sharedpreferences_token",token );
        editor.apply ();
    }
    public String  readToken()
    {
        String token;
        token = sp.getString(ct.getResources().getString(R.string.token),"0");
        return token;
    }


}
