package com.abc.buisnesscontact.Config;


import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

public class Loading extends AsyncTask<Void, Void, Void> {

    Loading loading;

    ProgressDialog pd;

//        private ProgressDialog dialog;
//
////        public Loading(Activity activity) {
////            dialog = new ProgressDialog(activity);
////        }

    public Loading(){
        super();
    }

    public Loading (Context context, String message, String title){
        pd = new ProgressDialog(context);
        pd.setTitle(title);
        pd.setMessage(message);
        pd.setCancelable(false);
        pd.setIndeterminate(false);


    }

    @Override
    protected Void doInBackground(Void... voids) {
//               try {
//                   //Do something...
//                   Thread.sleep(5000);
//               } catch (InterruptedException e) {
//                   // TODO Auto-generated catch block
//                   e.printStackTrace();
//               }
        return null;
    }

    @Override
    public void onPreExecute() {
//            super.onPreExecute();
//            dialog = ProgressBarUtility.getProgressDialog(getApplicationContext());
//            dialog.setCanceledOnTouchOutside(false);
//            dialog.setCancelable(false);
//            if (dialog != null) {
//                dialog.show();
//            }

//               pd = new ProgressDialog(AdminLogin.this);
//               pd.setTitle("Processing...");
//               pd.setMessage("Please wait.");
//               pd.setCancelable(false);
//               pd.setIndeterminate(true);

        pd.show();

    }



    @Override
    public void onPostExecute(Void result) {
        if (pd!=null)
        {
            pd.dismiss();
        }

    }



}
