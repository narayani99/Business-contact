package com.abc.buisnesscontact.Models;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;

public class ModuleFunctionModel extends Model {
    @Column
    public String ModuleName;
    @Column
    public String ModuleId;
    @Column
    public String FunctionId;
    @Column
    public String FunctionName;

    public String getModuleName() {
        return ModuleName;
    }

    public void setModuleName(String moduleName) {
        ModuleName = moduleName;
    }

    public String getModuleId() {
        return ModuleId;
    }

    public void setModuleId(String moduleId) {
        ModuleId = moduleId;
    }

    public String getFunctionId() {
        return FunctionId;
    }

    public void setFunctionId(String functionId) {
        FunctionId = functionId;
    }

    public String getFunctionName() {
        return FunctionName;
    }

    public void setFunctionName(String functionName) {
        FunctionName = functionName;
    }
}
