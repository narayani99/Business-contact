package com.abc.buisnesscontact.Models.Response.Account;

public class AuthRes
{
    String StatusCode;
    String Message;
    AuthToken Data;

    public String getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(String statusCode) {
        StatusCode = statusCode;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public AuthToken getData() {
        return Data;
    }

    public void setData(AuthToken data) {
        Data = data;
    }


}
