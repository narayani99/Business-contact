package com.abc.buisnesscontact.Models.Request.Account;

public class AuthReq
{
    public String LoginId;
    public String Password;

    public String getLoginId() {
        return LoginId;
    }

    public void setLoginId(String loginId) {
        LoginId = loginId;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }


}
