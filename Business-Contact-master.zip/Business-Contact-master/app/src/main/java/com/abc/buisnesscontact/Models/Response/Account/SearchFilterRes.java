package com.abc.buisnesscontact.Models.Response.Account;

public class SearchFilterRes {

    public String BCId;
    public String ContactPerson;
    public String Designation;
    public String Company;


    public String getBCId() {
        return BCId;
    }

    public void setBCId(String BCId) {
        this.BCId = BCId;
    }

    public String getContactPerson() {
        return ContactPerson;
    }

    public void setContactPerson(String contactPerson) {
        ContactPerson = contactPerson;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String designation) {
        Designation = designation;
    }

    public String getCompany() {
        return Company;
    }

    public void setCompany(String company) {
        Company = company;
    }
}
