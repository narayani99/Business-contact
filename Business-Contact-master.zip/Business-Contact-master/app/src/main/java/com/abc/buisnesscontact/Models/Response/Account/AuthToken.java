package com.abc.buisnesscontact.Models.Response.Account;

public class AuthToken
{
    public int UserId;

    public String ORoleId;

    public String ORole;

    public String FName;

    public String MName;

    public String LName;

    public String OEmailId;

    public String MobileNo;

    public String PFileName;

    public String Token;

    ModuleFunction moduleFunction;

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public String getORoleId() {
        return ORoleId;
    }

    public void setORoleId(String ORoleId) {
        this.ORoleId = ORoleId;
    }

    public String getORole() {
        return ORole;
    }

    public void setORole(String ORole) {
        this.ORole = ORole;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getMName() {
        return MName;
    }

    public void setMName(String MName) {
        this.MName = MName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public String getOEmailId() {
        return OEmailId;
    }

    public void setOEmailId(String OEmailId) {
        this.OEmailId = OEmailId;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getPFileName() {
        return PFileName;
    }

    public void setPFileName(String PFileName) {
        this.PFileName = PFileName;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public ModuleFunction getModuleFunction() {
        return moduleFunction;
    }

    public void setModuleFunction(ModuleFunction moduleFunction) {
        this.moduleFunction = moduleFunction;
    }
}
