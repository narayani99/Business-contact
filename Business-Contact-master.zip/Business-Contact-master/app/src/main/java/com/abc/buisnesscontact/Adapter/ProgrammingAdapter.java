package com.abc.buisnesscontact.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.abc.buisnesscontact.Models.Response.Account.SearchFilterRes;
import com.abc.buisnesscontact.R;

import java.util.ArrayList;

public class ProgrammingAdapter extends RecyclerView.Adapter<ProgrammingAdapter.ProgrammingViewHolder> {
    private ArrayList<SearchFilterRes> data;
    public ProgrammingAdapter(ArrayList<SearchFilterRes> data)
    {
        this.data = data;

    }
    @NonNull
    @Override
    public ProgrammingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate( R.layout.searched_card,parent,false);
        return new ProgrammingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProgrammingViewHolder holder, int position) {
        String name1 = data.get ( position ).getContactPerson ();
        String desig = data.get ( position ).getDesignation ();
        String company1 = data.get ( position ).getCompany ();
        holder.name.setText(name1);
        holder.designation.setText ( desig );
        holder.company.setText ( company1 );



    }

    @Override
    public int getItemCount() {
        return data.size ();
    }

    public class ProgrammingViewHolder extends RecyclerView.ViewHolder{
        TextView name,company;
        TextView designation;
        public ProgrammingViewHolder(View itemView){
            super(itemView);
            name = itemView.findViewById(R.id.item_name);
            designation = itemView.findViewById(R.id.item_detail);
            company = itemView.findViewById(R.id.item_company);
        }

    }

}
