package com.abc.buisnesscontact.Models;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;

public class User_landline_no extends Model {
    @Column(onDelete = Column.ForeignKeyAction.CASCADE)
    public Users user;

    @Column
    public String landline_number;

    public String getNumber(){
        return landline_number;
    }

    public void setNumber(String number){
        this.landline_number = number;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }
}


