package com.abc.buisnesscontact.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.abc.buisnesscontact.Activities.MainActivity;
import com.abc.buisnesscontact.Adapter.ProgrammingAdapter;
import com.abc.buisnesscontact.Adapter.ViewHolder;
import com.abc.buisnesscontact.ApiClient.ControllerMethod;
import com.abc.buisnesscontact.Config.Loading;
import com.abc.buisnesscontact.Models.Request.Account.SearchFilterReq;
import com.abc.buisnesscontact.Models.Response.Account.SearchFilterRes;
import com.abc.buisnesscontact.R;
import com.abc.buisnesscontact.SharedPreference;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ViewContactsFragment extends Fragment implements ControllerMethod.SearchResponse, ControllerMethod.GetTopContactRes {


    public ViewContactsFragment() {
        // Required empty public constructor
    }

    Loading loading;
    RecyclerView recyclerView;
    SharedPreference sharedPreference;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate ( R.layout.fragment_view_contacts, container, false );
        ((MainActivity) getActivity ()).setActionBarTitle ( "Contacts Manager" );


        SearchFilterReq searchFilterReq = new SearchFilterReq ();
        sharedPreference = new SharedPreference ( getContext () );
        searchFilterReq.setToken ( sharedPreference.readToken () );
        searchFilterReq.setFilter ( "*" );
        recyclerView = view.findViewById ( R.id.programmingList );
        recyclerView.setLayoutManager ( new LinearLayoutManager ( getContext () ) );
        loading = new Loading (getActivity (), "Fetching..", "Please Wait....");
        loading.onPreExecute ();
        new ControllerMethod ().SearchContacts ( searchFilterReq,this );



//        new ControllerMethod ().TopContact ( getTopReq,this );
        return view;
    }

    @Override
    public void Searched(int statusCode, String message,  ArrayList<SearchFilterRes> token) {
        try {

            loading.onPostExecute ( null );
            if (statusCode == 200) {
                recyclerView.setAdapter ( new ProgrammingAdapter ( token ) );


            } else if (statusCode == 207) {
                Toast.makeText ( getActivity (), "Not Found", Toast.LENGTH_SHORT ).show ();
            } else if (statusCode == 406) {
                Toast.makeText ( getActivity (), "Invalid request", Toast.LENGTH_SHORT ).show ();
            } else if (statusCode == 500) {
                Toast.makeText ( getActivity (), "Service Error", Toast.LENGTH_SHORT ).show ();
            } else if (statusCode == 401) {
                Toast.makeText ( getActivity (), "Invalid Credential", Toast.LENGTH_SHORT ).show ();
            }
        } catch (Exception e) {
        }
    }

    @Override
    public void GotTopContact(int statusCode, String message,  ArrayList<SearchFilterRes>  token) {
        try {

            loading.onPostExecute ( null );
            if (statusCode == 200) {
                ArrayList<SearchFilterRes>  data = token;



            } else if (statusCode == 406) {
                Toast.makeText ( getActivity (), "Invalid request", Toast.LENGTH_SHORT ).show ();
            } else if (statusCode == 500) {
                Toast.makeText ( getActivity (), "Service Error", Toast.LENGTH_SHORT ).show ();
            } else if (statusCode == 401) {
                Toast.makeText ( getActivity (), "Invalid Credential", Toast.LENGTH_SHORT ).show ();
            }
        } catch (Exception e) {
        }
    }
}

