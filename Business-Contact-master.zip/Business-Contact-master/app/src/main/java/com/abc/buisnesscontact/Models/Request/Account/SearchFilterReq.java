package com.abc.buisnesscontact.Models.Request.Account;

import com.abc.buisnesscontact.Models.Response.Account.AuthToken;

public class SearchFilterReq {
    public String Filter;

    public String Token;

    public String getFilter() {
        return Filter;
    }

    public void setFilter(String filter) {
        Filter = filter;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }
}
