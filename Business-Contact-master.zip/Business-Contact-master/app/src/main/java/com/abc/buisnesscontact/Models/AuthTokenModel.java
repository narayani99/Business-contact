package com.abc.buisnesscontact.Models;

import com.abc.buisnesscontact.Models.Response.Account.AuthToken;
import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;
import com.activeandroid.query.Select;

import java.util.ArrayList;
import java.util.List;

@Table ( name = "AuthTokenModel" )
public class AuthTokenModel extends Model {

    public AuthTokenModel()
    {
        this.moduleFunction = new ArrayList<> ();
    }
    @Column
    public int UserId;
    @Column
    public String ORoleId;
    @Column
    public String ORole;
    @Column
    public String FName;
    @Column
    public String MName;
    @Column
    public String LName;
    @Column
    public String OEmailId;
    @Column
    public String MobileNo;
    @Column
    public String PFileName;
    @Column
    public String Token;
    @Column
    List<ModuleFunctionModel> moduleFunction;

    @Column
    public String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public String getORoleId() {
        return ORoleId;
    }

    public void setORoleId(String ORoleId) {
        this.ORoleId = ORoleId;
    }

    public String getORole() {
        return ORole;
    }

    public void setORole(String ORole) {
        this.ORole = ORole;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getMName() {
        return MName;
    }

    public void setMName(String MName) {
        this.MName = MName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public String getOEmailId() {
        return OEmailId;
    }

    public void setOEmailId(String OEmailId) {
        this.OEmailId = OEmailId;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getPFileName() {
        return PFileName;
    }

    public void setPFileName(String PFileName) {
        this.PFileName = PFileName;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public List<ModuleFunctionModel> getModuleFunction() {
        return moduleFunction;
    }

    public void setModuleFunction(List<ModuleFunctionModel> moduleFunction) {
        this.moduleFunction = moduleFunction;
    }

    public static List<AuthTokenModel> getAll()
    {
        return new Select (  ).from ( AuthTokenModel.class ).execute ();
    }
}
