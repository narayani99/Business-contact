package com.abc.buisnesscontact.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.abc.buisnesscontact.R;

public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public CardView cardView;
    public ViewHolder(@NonNull View itemView) {
        super ( itemView );
        cardView = itemView.findViewById ( R.id.card_view );
        cardView.setOnClickListener ( this );
    }

    @Override
    public void onClick(View v) {
    }
}
