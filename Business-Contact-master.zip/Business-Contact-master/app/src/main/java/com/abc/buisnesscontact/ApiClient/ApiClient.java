package com.abc.buisnesscontact.ApiClient;

import com.abc.buisnesscontact.Models.Request.Account.GetTopReq;
import com.abc.buisnesscontact.Models.Request.Account.SearchFilterReq;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.joda.time.DateTime;

import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.schedulers.Schedulers;
import rx.Observable;
public class ApiClient
{

    public static  String BASE_URL = "http://test.brdin.in/tcph/api/";

    private static Retrofit retrofit = null;

    public static Retrofit getApiClient()
    {

        if ( retrofit == null)
        {
            Gson gson = new GsonBuilder ()
                    .setDateFormat("yyyy-MM-dd'T'HH:mm:ss")
                    .registerTypeAdapter( DateTime.class,new DateSerializer())
                    .create();
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory( GsonConverterFactory.create(gson))
                    .addCallAdapterFactory( RxJavaCallAdapterFactory.createWithScheduler( Schedulers.io()))
                    .build();
        }
        return  retrofit;
    }


    protected interface AtDeviceController
    {

        @POST(value = "account/auth")
        public Observable<Response<com.abc.buisnesscontact.Models.Response.Account.AuthRes>> LoginAuth(@Body com.abc.buisnesscontact.Models.Request.Account.AuthReq login);

        @POST(value = "bc/search")
        public Observable<Response<com.abc.buisnesscontact.Models.Response.Account.SearchRes>> Search(@Body SearchFilterReq req);

        @POST(value = "bc/GetMyTopContact")
        public Observable<Response<com.abc.buisnesscontact.Models.Response.Account.SearchRes>> getTop(@Body GetTopReq req);


    }



    public  static AtDeviceController AtDeviceClient()
    {
        return  getApiClient().create(AtDeviceController.class);
    }

}
