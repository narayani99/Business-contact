package com.abc.buisnesscontact.Activities;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.abc.buisnesscontact.Fragments.LoginPageFragment;
import com.abc.buisnesscontact.Fragments.SignupFragment;
import com.abc.buisnesscontact.Models.AuthTokenModel;
import com.abc.buisnesscontact.Models.Users;
import com.abc.buisnesscontact.R;
import com.abc.buisnesscontact.SharedPreference;
import com.activeandroid.query.Select;

import java.util.List;

public class OpenFirstPageActivity extends AppCompatActivity implements LoginPageFragment.LoginFragmentInterface, SignupFragment.SignupFragmentInterface
{

    private SharedPreference sharedPreference;
    public static FragmentManager fragmentManager;
    public CardView cardView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_open_first_page );

        fragmentManager = getSupportFragmentManager ();
        Toolbar toolbar = findViewById ( R.id.toolbar );
        setSupportActionBar ( toolbar );
        toolbar.getOverflowIcon().setColorFilter( Color.parseColor("#000000"), PorterDuff.Mode.SRC_ATOP);


        sharedPreference = new SharedPreference (getApplicationContext());
        if(sharedPreference.readLoginStatus())
        {
            startActivity(new Intent (this,MainActivity.class));
            finish();
        }
        else
        {

            if(findViewById(R.id.first_page_container)!=null)
            {
                if(savedInstanceState != null)
                {
                    return;
                }

                LoginPageFragment loginPageFragment = new LoginPageFragment ();
                fragmentManager.beginTransaction ()
                        .add ( R.id.first_page_container, loginPageFragment,null)
                        .commit ();
            }

        }
    }

    @Override
    public void commuicate(int method, String uname,String password) {
        switch (method)
        {
            case 0:

            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
            sharedPreference.writeLoginStatus(true);
            sharedPreference.writeUsername ( uname );
            finish();
            Toast.makeText ( getApplicationContext (), "Welcome "+uname+"!!!", Toast.LENGTH_LONG ).show ();
            break;
            case 1:
                SignupFragment signupFragment = new SignupFragment ();
                fragmentManager.beginTransaction ()
                        .replace ( R.id.first_page_container,signupFragment ,null)
                        .addToBackStack ( null )
                        .commit ();
                break;

        }
    }

    @Override
    public void login(AuthTokenModel token) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        sharedPreference.writeLoginStatus(true);
        sharedPreference.writeUsername ( token.getFName () );
        sharedPreference.writeOUserid ( token.getUserId () );
        sharedPreference.writeToken ( token.getToken () );
        finish();
        Toast.makeText ( getApplicationContext (), "Welcome "+token.FName, Toast.LENGTH_LONG ).show ();
    }

    @Override
    public void commuicates(int method) {
        switch (method)
        {
            case 0:
                LoginPageFragment loginFragment = new LoginPageFragment ();
                fragmentManager.beginTransaction ()
                        .replace ( R.id.first_page_container,loginFragment ,null)
                        .addToBackStack ( null )
                        .commit ();
                break;
        }
    }


    public static List<Users> getAll(){

        return new Select().from ( Users.class ).orderBy ( "user_name" ).execute ();
    }

    public void setActionBarTitle(String title) {
        getSupportActionBar().setTitle(title);
    }

}
