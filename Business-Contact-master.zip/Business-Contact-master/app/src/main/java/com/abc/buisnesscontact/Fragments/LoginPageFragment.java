package com.abc.buisnesscontact.Fragments;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.abc.buisnesscontact.Activities.OpenFirstPageActivity;
import com.abc.buisnesscontact.ApiClient.ControllerMethod;
import com.abc.buisnesscontact.Config.Loading;
import com.abc.buisnesscontact.Models.AuthTokenModel;
import com.abc.buisnesscontact.Models.Request.Account.AuthReq;
import com.abc.buisnesscontact.Models.Response.Account.AuthToken;
import com.abc.buisnesscontact.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class LoginPageFragment extends Fragment implements View.OnClickListener, ControllerMethod.OnLoginAuthRes {

    Loading loading;
    @Override
    public void onLoginAuthOk(int statusCode, String message, AuthToken token,String username)
    {
        try
        {

            loading.onPostExecute ( null );
            if (statusCode == 200)
            {
                AuthToken t = token;
                AuthTokenModel authTokenModel = new AuthTokenModel ();
                authTokenModel.setUsername ( username );
                authTokenModel.setFName ( t.getFName () );
                authTokenModel.setLName ( t.getLName () );
                authTokenModel.setMName ( t.getMName () );
                authTokenModel.setMobileNo ( t.getMobileNo () );
                authTokenModel.setOEmailId ( t.getOEmailId () );
                authTokenModel.setORole ( t.getORole () );
                authTokenModel.setPFileName ( t.getPFileName () );
                authTokenModel.setToken ( t.getToken () );
                authTokenModel.setUserId ( t.getUserId () );
                authTokenModel.setORoleId ( t.getORoleId () );
                authTokenModel.save ();
                loginFragmentInterface.login ( authTokenModel );

            }
            else if(statusCode==404){
                Toast.makeText ( getActivity (),"Invalid Credential",Toast.LENGTH_SHORT ).show ();;
            }

        }
        catch (Exception e){}
    }

    public interface LoginFragmentInterface {
        public void commuicate(int method,String uname,String password);
        public void login(AuthTokenModel token);

    }

    public LoginPageFragment() {
        // Required empty public constructor
    }

    private Button login_btn, signup_btn;
    private EditText username_text,password_text;
    FragmentManager fragmentManager;
    LoginFragmentInterface loginFragmentInterface;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate ( R.layout.fragment_login_page, container, false );

        ((OpenFirstPageActivity) getActivity ()).setActionBarTitle ( "Login to Buisness Contacts" );
        login_btn = view.findViewById ( R.id.login_loginbtn );
        signup_btn = view.findViewById ( R.id.login_signupbtn );

        login_btn.setOnClickListener ( this );
        signup_btn.setOnClickListener ( this );

        username_text = view.findViewById ( R.id.login_username );
        password_text = view.findViewById ( R.id.login_password );

        return view;
    }

    @Override
    public void onClick(View v) {


        switch (v.getId ()) {
            case R.id.login_loginbtn:
                String uname = username_text.getText ().toString ();
                String password = password_text.getText ().toString ();
                loading = new Loading (getActivity (), "Authentication", "Please Wait....");
                loading.onPreExecute();
                List<AuthTokenModel> authTokenModelList= new ArrayList<AuthTokenModel> (  );
                authTokenModelList = AuthTokenModel.getAll ();
                int i;
                for(i = 0;i< authTokenModelList.size();i++)
                {
                    if(uname.equals (authTokenModelList.get ( i ).getUsername ())){
                        loginFragmentInterface.login ( authTokenModelList.get(i) );;
                        break;
                    }
                }
                AuthReq req = new AuthReq (); req.LoginId=uname; req.Password=password;
                new ControllerMethod ().LoginAuth ( req,this );
                break;
            case R.id.login_signupbtn:
                loginFragmentInterface.commuicate ( 1 ,"","");
                break;
        }

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach ( context );
        Activity activity = (Activity) context;

        try {
            loginFragmentInterface = (LoginFragmentInterface) activity;

        } catch (ClassCastException e) {
            throw new ClassCastException ( activity.toString () + "Must Override" );
        }
    }
}
