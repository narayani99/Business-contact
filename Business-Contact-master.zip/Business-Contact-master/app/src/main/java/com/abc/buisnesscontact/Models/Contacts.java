package com.abc.buisnesscontact.Models;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;

import java.util.ArrayList;
import java.util.List;

public class Contacts extends Model {
    @Column
    public String first_name;

    @Column
    public String surname;

    @Column
    public String contact_designation;

    @Column
    public String contact_company;

    @Column
    public String contact_email;

    @Column
    public double contact_fax_no;

    @Column
    public String contact_company_website;

    @Column
    public String contact_business_card_image;

    @Column
    public List<User_mobile_no> contact_mobile_no=new ArrayList<User_mobile_no>();

    @Column
    public List <User_landline_no> contact_landline_no = new ArrayList<User_landline_no> ();


    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getContact_designation() {
        return contact_designation;
    }

    public void setContact_designation(String contact_designation) {
        this.contact_designation = contact_designation;
    }

    public String getContact_company() {
        return contact_company;
    }

    public void setContact_company(String contact_company) {
        this.contact_company = contact_company;
    }

    public String getContact_email() {
        return contact_email;
    }

    public void setContact_email(String contact_email) {
        this.contact_email = contact_email;
    }

    public double getContact_fax_no() {
        return contact_fax_no;
    }

    public void setContact_fax_no(double contact_fax_no) {
        this.contact_fax_no = contact_fax_no;
    }

    public String getContact_company_website() {
        return contact_company_website;
    }

    public void setContact_company_website(String contact_company_website) {
        this.contact_company_website = contact_company_website;
    }

    public String getContact_business_card_image() {
        return contact_business_card_image;
    }

    public void setContact_business_card_image(String contact_business_card_image) {
        this.contact_business_card_image = contact_business_card_image;
    }

    public List<User_mobile_no> getUser_mobile_no() {
        return contact_mobile_no;
    }

    public void setUser_mobile_no(String number) {
        User_mobile_no newUserMobile = new User_mobile_no();
        newUserMobile.setNumber(number);
        contact_mobile_no.add(newUserMobile);
    }

    public List<User_landline_no> getUser_landline_no() {
        return contact_landline_no;
    }

    public void setUser_landline_no(String number) {
        User_landline_no newUserLandline = new User_landline_no();
        newUserLandline.setNumber(number);
        contact_landline_no.add(newUserLandline);
    }


}
