package com.abc.buisnesscontact.Models.Response.Account;

import java.util.ArrayList;

public class SearchRes {

    String StatusCode;
    String Message;
    ArrayList<SearchFilterRes> Data;

    public String getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(String statusCode) {
        StatusCode = statusCode;
    }

    public  ArrayList<SearchFilterRes>  getData() {
        return Data;
    }

    public void setData( ArrayList<SearchFilterRes>  data) {
        Data = data;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

}
