package com.abc.buisnesscontact.Fragments;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.abc.buisnesscontact.Activities.OpenFirstPageActivity;
import com.abc.buisnesscontact.Models.Users;
import com.abc.buisnesscontact.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class SignupFragment extends Fragment implements View.OnClickListener {


    private EditText Insert_name,Insert_fname,Insert_lname,Insert_mobile,Insert_password,Insert_email,Insert_cnfpassword;
    private Button Insert_button;
    public interface SignupFragmentInterface {
        public void commuicates(int method);
    }
    SignupFragmentInterface signuppageInterface;

    public SignupFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_signup, container, false);
        ((OpenFirstPageActivity) getActivity ()).setActionBarTitle ( "SignUp to Buisness Contacts" );
        Insert_name = view.findViewById(R.id.insert_name);
        Insert_mobile = view.findViewById ( R.id.insert_mobile );
        Insert_fname = view.findViewById ( R.id.insert_fname );
        Insert_lname = view.findViewById ( R.id.insert_lname );
        Insert_email = view.findViewById ( R.id.insert_email );
        Insert_password = view.findViewById ( R.id.insert_password );
        Insert_cnfpassword = view.findViewById ( R.id.insert_cnfpassword );



        Insert_button = view.findViewById(R.id.insert_button);
        Insert_button.setOnClickListener(this);
        return view;
    }
    @Override
    public void onClick(View view) {

        String insert_name = Insert_name.getText().toString();
        String insert_email = Insert_email.getText().toString();
        String insert_fname = Insert_fname.getText().toString();
        String insert_lname = Insert_lname.getText().toString();
        String insert_mobile = Insert_mobile.getText().toString();
        String insert_password = Insert_password.getText().toString();
        String insert_cnfpassword = Insert_cnfpassword.getText ().toString ();


        if(insert_cnfpassword.equals ( insert_password )&& !insert_password.equals ( "" ) && !insert_name.equals ( "" )&& !insert_email.equals ( "" )&& !insert_fname.equals ( "" )&& !insert_lname.equals ( "" )&& !insert_mobile.equals ( "" )){
            Users user = new Users();
            user.setUser_name(insert_name);
            user.setUser_email(insert_email);
            user.setFname ( insert_fname );
            user.setLname ( insert_lname );
            user.setMobilenumber ( insert_mobile );
            user.setPassword ( insert_password );
            user.save();
            Toast.makeText(getActivity(),"Success",Toast.LENGTH_SHORT).show();
            signuppageInterface.commuicates ( 0 );

        }
        else if(!insert_cnfpassword.equals ( insert_password ))
        {
            Toast.makeText ( getActivity (),"Password Fields Do not match.",Toast.LENGTH_SHORT ).show ();
        }else
        {
            Toast.makeText ( getActivity (),"Empty Fields",Toast.LENGTH_SHORT ).show ();

        }


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach ( context );
        Activity activity = (Activity) context;

        try {
            signuppageInterface = (SignupFragmentInterface) activity;

        } catch (ClassCastException e) {
            throw new ClassCastException ( activity.toString () + "Must Override" );
        }
    }
}
