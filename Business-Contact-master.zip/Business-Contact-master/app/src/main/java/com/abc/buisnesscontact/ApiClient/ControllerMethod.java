package com.abc.buisnesscontact.ApiClient;

import android.util.Log;

import com.abc.buisnesscontact.Models.Request.Account.AuthReq;
import com.abc.buisnesscontact.Models.Request.Account.GetTopReq;
import com.abc.buisnesscontact.Models.Request.Account.SearchFilterReq;
import com.abc.buisnesscontact.Models.Response.Account.AuthRes;
import com.abc.buisnesscontact.Models.Response.Account.AuthToken;
import com.abc.buisnesscontact.Models.Response.Account.SearchFilterRes;
import com.abc.buisnesscontact.Models.Response.Account.SearchRes;

import java.util.ArrayList;

import retrofit2.HttpException;
import retrofit2.Response;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.exceptions.OnErrorNotImplementedException;
import rx.schedulers.Schedulers;

public class ControllerMethod
{
    public interface OnLoginAuthRes
    {
        public void onLoginAuthOk(int statusCode, String message, AuthToken token,String username);
    }

    public interface SearchResponse
    {
        public void Searched(int statusCode, String message,  ArrayList<SearchFilterRes> token);
    }

    public interface GetTopContactRes
    {
        public void GotTopContact(int statusCode,String message,  ArrayList<SearchFilterRes>  token);
    }


    public void LoginAuth(final AuthReq req, final OnLoginAuthRes callback )
    {
        Subscription subscribe= null;
        final int com=0;
        try {
            ApiClient.AtDeviceController service = ApiClient.AtDeviceClient();

            subscribe = service.LoginAuth(req)
                    .observeOn( AndroidSchedulers.mainThread())
                    .subscribeOn( Schedulers.io())
                    .subscribe(new Subscriber<Response<AuthRes>> ()
                    {
                        @Override
                        public void onCompleted()
                        {

                        }

                        @Override
                        public void onError(Throwable e) {
                            HttpException r = (HttpException) e;
                            if (r != null)
                            {
                                callback.onLoginAuthOk(r.code(), r.message(), null,"");
                            }
                            else
                            {
                                callback.onLoginAuthOk(0, r.message(), null,"");
                            }

                        }

                        @Override
                        public void onNext(Response response)
                        {

                            if (response.isSuccessful())
                            {

                                AuthRes token = (AuthRes) response.body();
                                onCompleted();
                                callback.onLoginAuthOk(response.code(), response.message(), token.getData (),req.getLoginId ());
                            }
                            else
                            {
                                onCompleted();
                                callback.onLoginAuthOk(response.code(),response.message(), null,"");
                            }

                        }
                    })
            ;

        }
        catch (OnErrorNotImplementedException e)
        {
            callback.onLoginAuthOk(0,e.getMessage(),null,"");
        }

        catch (Exception ex)
        {
            String m = ex.getMessage();
            Log.d("LoginAuth", "Error" + m);
        }



    }


    public void SearchContacts(final SearchFilterReq req, final SearchResponse callback )
    {
        Subscription subscribe= null;
        final int com=0;
        try {
            ApiClient.AtDeviceController service = ApiClient.AtDeviceClient();
            subscribe = service.Search (req)
                    .observeOn( AndroidSchedulers.mainThread())
                    .subscribeOn( Schedulers.io())
                    .subscribe(new Subscriber<Response<SearchRes>> ()
                    {
                        @Override
                        public void onCompleted()
                        {

                        }

                        @Override
                        public void onError(Throwable e) {
                            HttpException r = (HttpException) e;
                            if (r != null)
                            {
                                callback.Searched (r.code(), r.message(), null);
                            }
                            else
                            {
                                callback.Searched(0, "", null);
                            }

                        }

                        @Override
                        public void onNext(Response response)
                        {

                            if (response.isSuccessful())
                            {

                                SearchRes token = (SearchRes) response.body();
                                onCompleted();
                                callback.Searched (response.code(), response.message(), token.getData ());
                            }
                            else
                            {
                                onCompleted();
                                callback.Searched (response.code(),response.message(), null);
                            }

                        }
                    })
            ;

        }
        catch (OnErrorNotImplementedException e)
        {
            String m =e.getMessage();
            callback.Searched (0,e.getMessage(),null);
        }

        catch (Exception ex)
        { String m = ex.getMessage();
            Log.d("Search", "Error" + m);
        }
    }

    public void TopContact(GetTopReq req, final SearchResponse callback )
    {
        Subscription subscribe= null;
        final int com=0;
        try {
            ApiClient.AtDeviceController service = ApiClient.AtDeviceClient();
            subscribe = service.getTop (req)
                    .observeOn( AndroidSchedulers.mainThread())
                    .subscribeOn( Schedulers.io())
                    .subscribe(new Subscriber<Response<SearchRes>> ()
                    {
                        @Override
                        public void onCompleted()
                        {

                        }

                        @Override
                        public void onError(Throwable e) {
                            HttpException r = (HttpException) e;
                            if (r != null)
                            {
                                callback.Searched (r.code(), r.message(), null);
                            }
                            else
                            {
                                callback.Searched(0, r.message(), null);
                            }

                        }

                        @Override
                        public void onNext(Response response)
                        {

                            if (response.isSuccessful())
                            {

                                SearchRes token = (SearchRes) response.body();
                                onCompleted();
                                callback.Searched (response.code(), response.message(), token.getData ());
                            }
                            else
                            {
                                onCompleted();
                                callback.Searched (response.code(),response.message(), null);
                            }

                        }
                    })
            ;

        }
        catch (OnErrorNotImplementedException e)
        {
            String m =e.getMessage();
            callback.Searched (0,e.getMessage(),null);
        }

        catch (Exception ex)
        { String m = ex.getMessage();
            Log.d("Search", "Error" + m);
        }
    }
}
