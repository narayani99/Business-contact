package com.abc.buisnesscontact.Models.Response.Account;

public class ModuleFunction  {
    public String ModuleName;
    public String ModuleId;
    public String FunctionId;
    public String FunctionName;

    public String getModuleName() {
        return ModuleName;
    }

    public void setModuleName(String moduleName) {
        ModuleName = moduleName;
    }

    public String getModuleId() {
        return ModuleId;
    }

    public void setModuleId(String moduleId) {
        ModuleId = moduleId;
    }

    public String getFunctionId() {
        return FunctionId;
    }

    public void setFunctionId(String functionId) {
        FunctionId = functionId;
    }

    public String getFunctionName() {
        return FunctionName;
    }

    public void setFunctionName(String functionName) {
        FunctionName = functionName;
    }


}
