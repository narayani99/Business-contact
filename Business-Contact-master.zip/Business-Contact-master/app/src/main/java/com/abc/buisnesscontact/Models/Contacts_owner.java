package com.abc.buisnesscontact.Models;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;

public class Contacts_owner extends Model {
    @Column(onDelete = Column.ForeignKeyAction.CASCADE)
    public Users user;

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }
}
