package com.abc.buisnesscontact.Models.Response.Account;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.query.Select;

import java.util.ArrayList;
import java.util.List;

public class Token extends Model {

    public Token()
{
    this.ModuleFunction = new ArrayList<> ();
}
    @Column
    public String Token;

    @Column
    public int UserId;
    @Column
    public String ORoleId;
    @Column
    public String ORole;
    @Column
    public String FName;
    @Column
    public String MName;
    @Column
    public String LName;
    @Column
    public String OEmailId;
    @Column
    public String MobileNo;
    @Column
    public String PFileName;
    @Column
    public List<ModuleFunction> ModuleFunction;

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public String getORoleId() {
        return ORoleId;
    }

    public void setORoleId(String ORoleId) {
        this.ORoleId = ORoleId;
    }

    public String getORole() {
        return ORole;
    }

    public void setORole(String ORole) {
        this.ORole = ORole;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getMName() {
        return MName;
    }

    public void setMName(String MName) {
        this.MName = MName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public String getOEmailId() {
        return OEmailId;
    }

    public void setOEmailId(String OEmailId) {
        this.OEmailId = OEmailId;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getPFileName() {
        return PFileName;
    }

    public void setPFileName(String PFileName) {
        this.PFileName = PFileName;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public static List<Token> getToken1(String uid)
    {
        return new Select ().from ( Token.class ).where ( "UserId = ?",uid ).execute ();
    }

}
